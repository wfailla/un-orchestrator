### How to include this files in a client authentication compiling
  * Extract archive file and copy all files under un-orchestrator/orchestrator/node_resource_manager/database_manager/SQLite
