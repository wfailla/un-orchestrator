### How to include this files in a client authentication compiling
  * Extract archive file and copy root folder under un-orchestrator/orchestrator/node_resource_manager/database_manager/SQLite
