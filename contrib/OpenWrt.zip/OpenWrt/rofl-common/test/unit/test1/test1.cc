/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#include <stdlib.h>
#include <stdio.h>

int main(int args, char** argv){
	
	//cfwdelem a;
	printf("Test 2");
	return EXIT_SUCCESS;
}
