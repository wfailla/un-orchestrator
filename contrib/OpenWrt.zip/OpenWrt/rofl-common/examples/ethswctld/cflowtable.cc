/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/*
 * cflowtable.cc
 *
 *  Created on: 15.08.2014
 *      Author: andreas
 */

#include "cflowtable.h"

using namespace rofl::examples::ethswctld;

std::map<rofl::cdptid, cflowtable*> cflowtable::flowtables;




