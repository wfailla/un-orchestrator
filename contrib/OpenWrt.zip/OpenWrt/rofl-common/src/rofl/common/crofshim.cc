/*
 * crofshim.cc
 *
 *  Created on: 22.01.2014
 *      Author: andi
 */

#include "rofl/common/crofshim.h"

using namespace rofl::common;




