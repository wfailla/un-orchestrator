### How to include this files in a double-decker compiling
  * Extract archive file and copy include folder under un-orchestrator/orchestrator/node_resource_manager/pub_sub_manager/plugins/DoubleDecker
