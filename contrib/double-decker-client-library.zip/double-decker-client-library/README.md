### Compile Double-Decker client

 * gcc  -g -O2 -Wno-format-security -shared -o libddclient.so -fPIC DDClient.c cli_parser/cparser_tree.c cli_parser/cparser.c cli_parser/cparser_fsm.c cli_parser/cparser_io_unix.c cli_parser/		cparser_line.c cli_parser/cparser_token.c cli_parser/cparser_token_tbl.c cli_parser/cparser.h cli_parser/cparser_tree.h cli_parser/cparser_fsm.h cli_parser/cparser_line.h cli_parser/cparser_token.h lib/keys.c lib/b64/cdecode.c lib/protocol.c -ljson -lsodium -lurcu-cds -lurcu -lczmq -lzmq
 * sudo cp libddclient.so /usr/local/lib
