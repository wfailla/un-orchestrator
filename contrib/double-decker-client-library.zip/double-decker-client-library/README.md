### Compile Double-Decker client

 * Extract archive file and copy content of folder under un-orchestrator/orchestrator/node_resource_manager/pub_sub_manager/plugins/DoubleDecker
 * under un-orchestrator/orchestrator/node_resource_manager/pub_sub_manager/plugins/DoubleDecker run the following command
 * gcc  -g -O2 -Wno-format-security -shared -o libddclient.so -fPIC DDClient.c cli_parser/cparser_tree.c cli_parser/cparser.c cli_parser/cparser_fsm.c cli_parser/cparser_io_unix.c cli_parser/cparser_line.c cli_parser/cparser_token.c cli_parser/cparser_token_tbl.c lib/keys.c lib/b64/cdecode.c lib/protocol.c -ljson -lsodium -lurcu-cds -lurcu -lczmq -lzmq
 * sudo cp libddclient.so /usr/local/lib
