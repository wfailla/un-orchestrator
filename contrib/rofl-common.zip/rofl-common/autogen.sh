#!/bin/sh

export AUTOMAKE="automake --foreign -a"
autoreconf -f -i
